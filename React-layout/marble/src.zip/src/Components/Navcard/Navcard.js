import React from "react";
import "./Navcard.scss";
import { images } from "../../image";

const Navcard = () => {
  return (
    <section className="navcard">
      <div className="logo-circle">
      <div className="navcard-logo">
        <img className="marble-button" src={images.button} />
      </div>
      <div className="circle"></div>
      </div>
      
      
      <div className="nav-container">
        <div className="navcard-h">
          <div className="card-navigation">
            <div className="navcard-left">
              <div className="dropdown">
                <a href="#" className="dropdown-btn">
                  Following
                </a>
              </div>
              <div className="nav-buttons">
                <a href="#" className="libraries">
                  <img className="checkbox" src={images.checkbox} />
                  libraries
                </a>
                <a href="#" className="libraries">
                  <img className="checkbox" src={images.checkbox} />
                  Collections
                </a>
                <a href="#" className="libraries">
                  <img className="checkbox" src={images.checkbox2} />
                  Luminaries
                </a>
              </div>
            </div>

            <div className="navcard-right">
              <form>
                <input type="search" placeholder="Search Feed" />
              </form>
              <img className="share" src={images.share} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Navcard;
