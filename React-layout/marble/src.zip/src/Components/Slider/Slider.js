import React from "react";

import "./Slider.scss";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { images } from "../../image";
import { Pagination, Navigation } from "swiper";


const Slider = () => {
    return (
        <section className="slider">
<div className="box-container">
                    <div className="mask2">
                        <div className="box">
            <div className="box-card">
                <div className="box-rect">
                    <div className="box-head">
                        <p className="marble">marble</p>
                        <p className="box-middle">
                            Follow their journey
                        </p>
                        <a href="#" className="box-end">
                            View all Marbles
                        </a>
                    </div>
                </div>

            </div>
            <Swiper
                slidesPerView={5}
                spaceBetween={0}
                slidesPerGroup={1}
                loop={true}
                loopFillGroupWithBlank={true}
                pagination={{
                    clickable: true,
                }}
                navigation={true}
                modules={[Pagination, Navigation]}
                className="mySwiper"
            >
                
                            <SwiperSlide>
                                <div className="box-card">
                                    <div className="blur-main">
                                        <img className="bg-blur" src={images.img1} />
                                        <div className="img-subpart">
                                            <img className="sub-img" src={images.arlene} />
                                            <p className="img-name">Arlene McCoy</p>
                                        </div>

                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="box-card">
                                    <div className="blur-main">
                                        <img className="bg-blur" src={images.img2} />
                                        <div className="img-subpart">
                                            <img className="sub-img" src={images.esteban} />
                                            <p className="img-name">Esteban Pena</p>
                                        </div>
                                    </div>

                                </div>
                            </SwiperSlide>

                            <SwiperSlide><div className="box-card">
                                <div className="blur-main">
                                    <img className="bg-blur" src={images.img3} />
                                    <div className="img-subpart">
                                        <img className="sub-img" src={images.martin} />
                                        <p className="img-name">Martin Russell</p>
                                    </div>
                                </div>

                            </div>
                            </SwiperSlide>

                            <SwiperSlide>
                                <div className="box-card">
                                    <div className="blur-main">
                                        <img className="bg-blur" src={images.img4} />
                                        <div className="img-subpart">
                                            <img className="sub-img" src={images.courtney} />
                                            <p className="img-name">Courtney Henry</p>
                                        </div>
                                    </div>

                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="box-card">
                                    <div className="blur-main">
                                        <img className="bg-blur" src={images.img5} />
                                        <div className="img-subpart">
                                            <img className="sub-img" src={images.devon} />
                                            <p className="img-name">Devon Steward</p>
                                        </div>
                                    </div>

                                </div>
                            </SwiperSlide>
                            </Swiper>

                        </div>
                    </div>

                </div>
           
        </section>
    )
}

export default Slider
