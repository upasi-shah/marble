import React from "react";
import "./Navbar.scss";
import { images } from "../../image";

const Navbar = () => {
  return (
    <section className="header">
      <div className="header-container">
        .
        <div className="header-main">
          <img className="logo" src={images.logo} />
          <div className="header-middele">
            <form>
              <input type="search" placeholder="Find luminaries" />
            </form>
          </div>
          <div className="header-side">
            <img className="notify" src={images.notification} />
            <img className="profile" src={images.profile} />
          </div>
        </div>
        <div className="header-lower">
          <div className="blue-bg"></div>
          <div className="header-left">
            
            <img className="header-avatar avt1" src={images.half} />
            <img className="header-avatar avt2" src={images.pic2} />
            <img className="header-avatar avt3" src={images.pic3} />
          </div>
          <div className="header-center">
            <p className="header-text">Welcome back, jane</p>
            <p className="header-subtext">Who will inspire you today?</p>
          </div>
          <div className="header-right">
            <img className="header-avatar avt4" src={images.pic4} />
            <img className="header-avatar avt5" src={images.pic5} />
            <img className="header-avatar avt6" src={images.pic6} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Navbar;
