import React from "react";
// import { XMasonry, XBlock } from "react-xmasonry";
import Masonry from 'masonry-layout';

import "./Card1.scss";
import $ from 'jquery';
import { images } from "../../image";
import { ReactComponent as Inspired } from "../../images/Inspired.svg";

const Card1 = () => {
  return (

    <section className="cards">
      <div className="card-container">
        <div className="mask">
        
          <div className="grid">
            <script src="/path/to/masonry.pkgd.min.js"></script>

            <div className="grid-item grid-item--width2">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img">
                      <img className="img1" src={images.ariana} />
                      <div className="img-text">
                        <p className="name-text">
                          Ariana Huffington <span className="f-btn">follow</span>
                        </p>
                        <span className="name-text extra">was part of a panel</span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <a href="#" className="feature">
                      Featured{" "}
                    </a>
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img className="avatar-img" src={images.avatar1} />
                </div>
                <div className="card-line">
                  <p className="head-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left"></div>
                  <p className="body-text">
                    Sleep is more important than you think to achieving business
                    success!
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.ariana} />
                      <div className="img-text">
                        <p className="name-text two-text">Ariana Huffington</p>
                        <span className="name-text extra two-text-e">
                          wrote and published a book
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img className="avatar-img" src={images.atomic} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    Atomic Habits: An Easy & Proven Way to Build Good Habits & Break
                    Bad Ones
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.amazon} />
                    <a href="#" className="v-text">
                      Amazon.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left h-line"></div>
                  <p className="body-text added">
                    Sleep is more important than you think to achieving business
                    success!
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>




            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.kristin} />
                      <div className="img-text">
                        <p className="name-text two-text">Kristin Watson</p>
                        <span className="name-text extra two-text-e">
                          was interviewed in a podcast
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="content">
                  <div className="card-image">
                    <img className="avatar-img boy" src={images.boy} />
                  </div>
                  <div className="content-text">
                    <p className="content-main">The Box</p>
                    <p className="sub-content">
                      Please Excuse Me For Being Antisocial

                    </p>
                  </div>
                </div>
                <div className="timeline">
                  <img className="icon-timeline" src={images.timeline} />
                  <img className="play" src={images.play} />
                </div>
                <div className="timing">
                  <p className="t1 t2">1:46</p>
                  <p className="t2">3:46</p>
                </div>


                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>

                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.bessie} />
                      <div className="img-text">
                        <p className="name-text two-text">Ariana Huffington</p>
                        <span className="name-text extra two-text-e">
                          wrote and published a book
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img className="avatar-img" src={images.plant} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    Atomic Habits: An Easy & Proven Way to Build Good Habits & Break
                    Bad Ones
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.amazon} />
                    <a href="#" className="v-text">
                      Amazon.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left h-line"></div>
                  <p className="body-text added">
                    Sleep is more important than you think to achieving business
                    success!
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.ariana} />
                      <div className="img-text">
                        <p className="name-text two-text">Jessica Smith</p>
                        <span className="name-text extra two-text-e">
                          was photographed
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image girl-bg">
                  <img className="gallery" src={images.gallery} />
                  <img className="avatar-img girl" src={images.girls} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.esther} />
                      <div className="img-text">
                        <p className="name-text two-text">Esther Howard</p>
                        <span className="name-text extra two-text-e">
                          recommended an article
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img className="avatar-img laptop" src={images.laptop} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left"></div>
                  <p className="body-text added">
                    This is a collection of great insights.
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>


            <div className="grid-item">
              <div className="card-item">
                <div className="img-only">
                  <div className="main-img">
                    <img className="watson" src={images.watson} />
                    <div className="overlay">
                      <img className="overlay-bg" src={images.overlay} />
                    </div>
                    <div className="img-top">
                      <p className="new">NEW</p>
                    </div>
                    <div className="img-bottom">
                      <p className="img-title para">Artist</p>
                      <p className="name para">Kristin Watson</p>
                      <div className="img-anchor">
                        <a href="#" className="follow para">
                          Follow
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="img-only">
                  <div className="main-img">
                    <img className="watson" src={images.floyd} />
                    <div className="overlay">
                      <img className="overlay-bg" src={images.overlay} />
                    </div>
                    <div className="img-top">
                      <p className="new">NEW</p>
                    </div>
                    <div className="img-bottom">
                      <p className="img-title para">Singer</p>
                      <p className="name para">Floyd Miles</p>
                      <div className="img-anchor">
                        <a href="#" className="follow para">
                          Follow
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.brooklyn} />
                      <div className="img-text">
                        <p className="name-text two-text">Brooklyn Simmons</p>
                        <span className="name-text extra two-text-e">
                          minted an NFT collecton
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img
                    className="avatar-img laptop content-img"
                    src={images.content}
                  />
                </div>
                <div className="card-tiles two-logo">
                  <div className="tiles-left two-logo-l">
                    <img className="vogue added-logo" src={images.etherscan} />
                    <a href="#" className="v-text">
                      Etherscan
                    </a>
                  </div>

                  <div className="tiles-left two-logo-l">
                    <img className="vogue added-logo" src={images.openocean} />
                    <a href="#" className="v-text">
                      OpenOcean
                    </a>
                  </div>

                  <div className="tiles-right two-logo-r" >
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.robert} />
                      <div className="img-text">
                        <p className="name-text two-text">Robert Fox</p>
                        <span className="name-text extra two-text-e">
                        gave a speech
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img
                    className="avatar-img laptop content-img"
                    src={images.window}
                  />
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left"></div>
                  <p className="body-text added">
                    This is a collection of great insights.
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>



            <div className="grid-item">
              <div className="card-item two-lines">
                <div className="two-part">
                  <div className="row-line ">
                    <div className="left-one line-two">
                      <img className="maria" src={images.maria} />
                      <div className="row-text">
                        <p className="upper">Maria Alecantor</p>
                        <p className=" upper lower">Science Writer</p>
                      </div>
                      <div className="right-btn">
                        <a href="#" className="follow-btn">
                          follow
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="line"></div>

                  <div className="row-line two-part">
                    <div className="left-one line-two">
                      <img className="maria" src={images.alecantor} />
                      <div className="row-text">
                        <p className="upper">Maria Alecantor</p>
                        <p className=" upper lower">Scientist</p>
                      </div>
                      <div className="right-btn">
                        <a href="#" className="follow-btn">
                          follow
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item grid-item--width2">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img">
                      <img className="img1" src={images.jess} />
                      <div className="img-text">
                        <p className="name-text">
                        Jess Warrington <span className="f-btn">follow</span>
                        </p>
                        <span className="name-text extra">was part of a panel</span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <a href="#" className="feature">
                      Featured{" "}
                    </a>
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img className="avatar-img" src={images.cafe} />
                </div>
                <div className="card-line">
                  <p className="head-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-headline2">
                  <div className="a-img t-img">
                    <img className="img1 t-img1" src={images.ariana} />
                    <div className="img-text t-text">
                      <p className="name-text name-t">
                        Ariana Huffington
                        <span className="name-text extra extra-t">
                          commented
                        </span>{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className="b-left"></div>
                  <p className="body-text">
                    Sleep is more important than you think to achieving business
                    success!
                  </p>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.ariana} />
                      <div className="img-text">
                        <p className="name-text two-text">Jessica Smith</p>
                        <span className="name-text extra two-text-e">
                          was photographed
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image girl-bg">
                  <img
                    className="gallery overlay-bg overlay2"
                    src={images.overlay2}
                  />
                  <img className="play play-back" src={images.play} />
                  <img className="avatar-img girl" src={images.party} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.bessie} />
                      <div className="img-text">
                        <p className="name-text two-text">Bessie Cooper</p>
                        <span className="name-text extra two-text-e">
                        was featured in a video
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image girl-bg">
                  <img
                    className="gallery overlay-bg overlay2"
                    src={images.overlay2}
                  />
                  <img className="play play-back" src={images.play} />
                  <img className="avatar-img girl" src={images.furniture} />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.robert} />
                      <div className="img-text">
                        <p className="name-text two-text">Floyd Miles</p>
                        <span className="name-text extra two-text-e">
                        added an image to their Path
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img
                    className="avatar-img laptop content-img cartoon"
                    src={images.miles}
                  />
                </div>
                <div className="card-line">
                  <p className="head-text second-text">
                    From Music to Startups, How the Artist James Blake Keeps
                    Reinventing Himself
                  </p>
                </div>
                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                
                
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.kristin} />
                      <div className="img-text">
                        <p className="name-text two-text">Devon Lane</p>
                        <span className="name-text extra two-text-e">
                        obtained an NFT
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="card-image">
                  <img
                    className="avatar-img laptop content-img"
                    src={images.skull}
                  />
                </div>
                <div className="card-tiles two-logo">
                  <div className="tiles-left two-logo-l">
                    <img className="vogue added-logo" src={images.etherscan} />
                    <a href="#" className="v-text">
                      Etherscan
                    </a>
                  </div>

                  <div className="tiles-left two-logo-l">
                    <img className="vogue added-logo" src={images.openocean} />
                    <a href="#" className="v-text">
                      OpenOcean
                    </a>
                  </div>

                  <div className="tiles-right two-logo-r" >
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>
                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid-item">
              <div className="card-item">
                <div className="card-headline">
                  <div className="card-left">
                    <div className="a-img s-img">
                      <img className="img1 s-img1" src={images.warren} />
                      <div className="img-text">
                        <p className="name-text two-text">Wade Warren</p>
                        <span className="name-text extra two-text-e">
                          was interviewed in a podcast
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="card-right">
                    <img className="menu-icon" src={images.menu} />
                  </div>
                </div>
                <div className="content">
                  <div className="card-image">
                    <img className="avatar-img boy" src={images.sing} />
                  </div>
                  <div className="content-text">
                    <p className="content-main">America’s Best Dinners: New Jersey</p>
                    <p className="sub-content">
                    Episode 1

                    </p>
                  </div>
                </div>
                <div className="timeline">
                  <img className="icon-timeline" src={images.timeline} />
                  <img className="play" src={images.play} />
                </div>
                <div className="timing">
                  <p className="t1 t2">1:46</p>
                  <p className="t2">3:46</p>
                </div>


                <div className="card-tiles">
                  <div className="tiles-left">
                    <img className="vogue" src={images.vogue} />
                    <a href="#" className="v-text">
                      Vogue.com
                    </a>
                  </div>
                  <div className="tiles-right">
                    <img className="interface right-logo" src={images.interface} />
                    <img className="save right-logo" src={images.save} />
                  </div>
                </div>

                <div className="line"></div>
                <div className="card-end">
                  <div className="end-left">
                    <img className="inspired l-logo" src={images.inspired} />
                    <span className="count e-text">35 inspired</span>
                    <img className="chat l-logo" src={images.chat} />
                    <span className="no e-text">12</span>
                  </div>
                  <div className="end-right">
                    <img className="eye r-logo" src={images.eye} />
                    <span className="view r-text">10k</span>
                    <img className="save1 r-logo" src={images.save2} />
                    <span className="saved r-text">34</span>
                  </div>
                </div>
              </div>
            </div>



          </div>
        </div>
      </div>
    </section>



  );
  $('.grid').masonry({
    itemSelector: '.grid-item',
    columnWidth: 0
  });

};

export default Card1;
