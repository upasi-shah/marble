import React from 'react';
import "./Explore.scss";
import { images } from "../../image";

const Explore = () => {
  return (
    <div>
        <div className='title-text'>
        <h3 className='explore'>Explore your feed</h3>
        </div>
     
    </div>
  )
}

export default Explore
