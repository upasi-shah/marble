import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Card1 from './Components/Card1/Card1';
import Slider from './Components/Slider/Slider';
import Navcard from './Components/Navcard/Navcard';
import Onclick from './Components/Onclick/Onclick';
import Explore from './Components/Explore/Explore';

function App() {
  return (
    <>
    <Navbar/>
    <Explore/>
    <Navcard/>
    <Slider/>
    
    
    <Card1/>
    
    </>
  );
}

export default App;
